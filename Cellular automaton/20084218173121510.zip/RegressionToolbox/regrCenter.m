
function [X,barX] = RegrCenter(DATA,barX)

%   [X,barX] = RegrCenter(DATA,barX)
%   [X,barX] = RegrCenter(DATA)
%
% Function for mean centering the data.
%
% Input parameter:
%  - DATA: Data to be modeled
%  - x0: Given point on the model hyperplane (optional)
% Return parameters:
%  - X: Moved data matrix
%  - barX: center of DATA
%
% Heikki Hyotyniemi Dec.1, 2000


[k,n] = size(DATA);
if (n>k) disp('Data matrix should be transposed?'); end

if nargin < 2
   barX = mean(DATA)';
end
   
X = DATA - ones(k,1)*barX';
