
function [U,Y] = DataDyn(d,n,m,k,sigma)

%   [U,Y] = DataDyn(d,n,m,k,sigma)
%   [U,Y] = DataDyn
%
% Generate random data coming from a state-space system.
%
% Input parameters:
%  - d: State dimension (default 1)
%  - n: Input dimension (default 1)
%       can be zero, meaning stochastic process,
%       or given predetermined input sequence
%  - m: Output dimension (default 1)
%  - k: Number of data samples (default 100)
%  - sigma: Standard deviation of the noise (default 0) 
% Return parameters:
%  - U: Input sequence
%  - Y: Output sequence
%
% Heikki Hyotyniemi Feb.20, 2001


if nargin < 1
   d = 1;
end
if nargin < 2
   n = 1;
end
if nargin < 3
   m = 1;
end
if nargin < 4
   k = 100;
end
if nargin < 5
   sigma = 0;
end
if n==0
   n = 1;
   U = zeros(k,n);
elseif length(n)>1
   U = n;
   [k,n] = size(U);
else
   U = randn(k,n);
end

A = randn(d,d);
A = A/max(abs(eig(A)))/1.1  % Stabilize!
B = randn(d,n)
C = randn(m,d)
D = randn(m,n)

eig(A)

E = sigma*randn(k,d+m);
EE = E*randn(d+m,d+m);
E1 = EE(:,1:d);
E2 = EE(:,d+1:d+m);
X = zeros(k+1,d);
Y = zeros(k,m);

for i = 1:k
   Y(i,:) = (C*X(i,:)')' + (D*U(i,:)')' + E2(i,:);
   X(i+1,:) = (A*X(i,:)')' + (B*U(i,:)')' + E1(i,:);
end

