
function [Yhat0,Yhat1,Xhat0,Xhat1] = RegrKalm(Y,A,C,Rxx,Ryy,Rxy,x0)

%   [Yhat0,Yhat1,Xhat0,Xhat1] = RegrKalm(Y,A,C,Rxx,Ryy,Rxy,x0)
%   [Yhat0,Yhat1,Xhat0,Xhat1] = RegrKalm(Y,A,C,Rxx,Ryy,Rxy)
%
% Discrete time stochastic Kalman filter (predictor).
%
% Input parameters:
%  - Y: Output data block (k x m)
%  - A,C,Rxx,Ryy,Rxy: System matrices
%  - x0: Initial state (default x0=0)
% Return parameters:
%  - Yhat0: Corresponding zero-lag output estimate (filter)
%  - Yhat1: One-step output estimate (predictor)
%  - Xhat0: State sequence estimate (k|k)
%  - Xhat1: State sequence estimate (k+1|k)
%
% Heikki Hyotyniemi Sep.13, 2000


[k,m] = size(Y);
[n1,n2] = size(A);
if n1~=n2, disp('Matrix A not square!'); 
else n = n1;
end

U = zeros(k,1);
B = zeros(n,1);
D = zeros(m,1);
if nargin == 7
   [Yhat0,Yhat1,Xhat0,Xhat1] = RegrKalman(U,Y,A,B,C,D,Rxx,Ryy,Rxy,x0);
else
   [Yhat0,Yhat1,Xhat0,Xhat1] = RegrKalman(U,Y,A,B,C,D,Rxx,Ryy,Rxy);
end


