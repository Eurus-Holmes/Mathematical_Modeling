
%
% Regression Toolbox for Matlab - Version 1.1
%
% See "Multivariate Regression - Techniques and Tools"
% HUT Control Engineering Laboratory, Report 125, 2003 (2nd edition)
%
% Heikki Hyotyniemi June 1, 2003
%
%
% Preprocessing commands:
%   regrCenter  -  Mean centering of data
%   regrScale   -  Normalization, variable variances getting scaled
%   regrWeight  -  Weighting of data samples
%   regrWhiten  -  "Whitening" of data: covariance becomes identity matrix
%   regrFixval  -  Iterative fixing of missing data values
%
% Cluster management:
%   regrFDA     -  Fisher Discriminant Analysis for distinguishing between clusters
%   regrForm    -  Histogram equalization (or deformation) model construction
%   regrDeform  -  Histogram equalization model application 
%   regrEM      -  Expectation Maximization clustering
%   regrKM      -  K-Means clustering of data
%   regrOutl    -  Visual outlier detection
%
% Structure refinement:
%   regrPCA     -  Standard Principal Component Analysis
%   regrPLS     -  Partial Least Squares analysis, formulated as an eigenproblem
%   regrCR      -  Continuum regression basis determination
%   regrCCA     -  Canonical Correlation Analysis
%   regrICA     -  Independent Component Analysis
%   regrRBFN    -  Radial Basis Function Network construction
%
% Model construction and regression:
%   regrMLR     -  Multi-Linear Regression
%   regrMLRC    -  Multi-Linear Regression with linear constraints
%   regrOLS     -  Orthogonal Least Squares algorithm
%   regrTLS     -  Total Least Squares regression
%   regrRR      -  Ridge Regression
%   regrRBFR    -  Radial Basis Function Regression
%
% Functions for dynamic systems:
%   regrBal     -  Balancing and reducing a dynamic state-space system
%   regrIdent   -  Black-box identification of ARX models
%   regrSSI     -  SubSpace Identification of dynamic systems
%   regrSSSI    -  Stochastic SubSpace Identification of dynamic systems
%
% Iterative demonstration algorithms:
%   regrHAH     -  Hebbian - Anti-Hebbian regression
%   regrPPCA    -  PCA using the power method
%   regrGHA     -  PCA using the Generalized Hebbian Algorithm
%   regrIICA    -  "Interactive" ICA
%
% Analysis and visualization:
%   regrCrossval    -  Cross-validation of the model
%   regrShowClust   -  Visualize the structure of clustered data
%   regrKalman      -  Implement discrete-time Kalman filter
%   regrKalm        -  Implement stochastic discrete-time Kalman filter
%   regrAskOrder    -  Visual tool for model order determination
%
% Test material:
%   dataXY          -  Generate random input-output data
%   dataClust       -  Generate random clustered data
%   dataIndep       -  Generate data consisting of independent signals
%   dataDyn         -  Generate random dynamic data
%   dataHeatExch    -  Heat exchanger data
%   dataEmotion     -  Voice signal data.
%
