
function [X,Y] = DataXY(k,n,m,dofx,dofy,sn,sm)

%   [X,Y] = DataXY(k,n,m,dofx,dofy,sn,sm)
%   [X,Y] = DataXY(k,n,m,dofx,dofy)
%   [X,Y] = DataXY(k,n,m)
%   [X,Y] = DataXY(k)
%   [X,Y] = DataXY
%
% Function generates random input-output data.
%
% Input parameters:
%  - k: Number of samples (default 100) 
%  - n: Input data dimension (default 5)
%  - m: Output data dimension (default 4)
%  - dofx: Independent input data dimension (default 3)
%  - dofy: Independent output data dimension (default 2)
%  - sn: Input noise level (default 0.001)
%  - sm: Output noise level (default 0.1)
% Return parameters:
%  - X: Input data matrix (collection of row data vectors)
%  - Y: Output data matrix (collection of row data vectors)
%
% Heikki Hyotyniemi Feb.12, 2001


if nargin < 1 | isnan(k)
   k = 100;
end
if nargin < 2 | isnan(n)
   n = 5;
end
if nargin < 3 | isnan(m)
   m = 4;
end
if nargin < 4 | isnan(dofx)
   dofx = min(n,3);
end
if nargin < 5 | isnan(dofy)
   dofy = min([m,dofx,2]);
end
if nargin < 6 | isnan(sn)
   sn = 0.001;
end
if nargin < 7 | isnan(sm)
   sm = 0.1;
end
if dofy > dofx
   disp('No more information in Y than in X!');
end

X0 = randn(k,dofx);
X = X0*randn(dofx,n) + sn*randn(k,n);
Y = X0(:,1:dofy)*randn(dofy,m) + sm*randn(k,m);
X = X./(ones(k,1)*sqrt(sum(X.*X)/k));
Y = Y./(ones(k,1)*sqrt(sum(Y.*Y)/k));
