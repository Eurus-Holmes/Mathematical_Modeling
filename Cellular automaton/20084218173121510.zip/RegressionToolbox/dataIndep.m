
function [X] = DataIndep(kk,func1,func2,func3,func4,func5,func6)

%   [X] = DataIndep(k,func1,func2,func3,func4,func5,func6)
%   [X] = DataIndep(k,func1,func2,func3,func4,func5)
%   [X] = DataIndep(k,func1,func2,func3,func4)
%   [X] = DataIndep(k,func1,func2,func3)
%   [X] = DataIndep(k,func1,func2)
%   [X] = DataIndep(k,func1)
%   [X] = DataIndep(k)
%   [X] = DataIndep
%
% Function mixes independent data sources (data whitened).
%
% Input parameters:
%  - k: Number of data samples (default 1000)
%  - func1,...,func6: If string, interpreted as a function of k
%    (note that this is denoted "kappa" in the text)
%    If a special string, interpreted as:
%      'f1' = sinusoid
%      'f2' = saw-tooth
%      'f3' = strange curve
%      'f4' = impulsive noise
%    (default "'f1','f2','f3','f4'")
% Return parameter:
%  - X: Data matrix (collection of row data vectors)
%
% Heikki Hyotyniemi Feb.12, 2000


if nargin < 1 | isnan(kk)
   kk = 1000;
end
k = [0:kk-1]';

if nargin < 2
   funcs = 4;
   func1 = 'f1';
   func2 = 'f2';
   func3 = 'f3';
   func4 = 'f4';
else
   funcs = nargin - 1;
end
XX = zeros(kk,funcs);

for i = 1:funcs
   eval(['func = func',num2str(i),';']);
   if strcmp(func,'f1'), func = 'sin(k/5)'; end
   if strcmp(func,'f2'), func = '(rem(k,27)-13)/9'; end
   if strcmp(func,'f3'), func = '((rem(k,23)-11)/9).^5'; end
   if strcmp(func,'f4'), func = '((rand(kk,1)<.5)*2-1).*log(rand(kk,1))'; end
   eval(['xx = ',func,';']);
   XX(:,i) = xx;   
end

figure(100)
for i = 1:funcs
   subplot(funcs,1,i);
   plot(XX(:,i))
end
title('Original signals');

XX = XX*randn(funcs,funcs);
XX = RegrCenter(XX);
X = RegrWhiten(XX);

figure(101)
for i = 1:funcs
   subplot(funcs,1,i);
   plot(X(:,i))
end
title('Mixed signals');
