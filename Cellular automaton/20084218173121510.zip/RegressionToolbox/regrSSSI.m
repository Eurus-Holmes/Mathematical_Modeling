
function [A,C,Rxx,Ryy,Rxy,X] = RegrSSSI(Y,maxdim,d)

%   [A,C,Rxx,Ryy,Rxy] = RegrSSSI(Y,maxdim,d)
%   [A,C,Rxx,Ryy,Rxy] = RegrSSSI(Y,maxdim)
%
% Stochastic SubSpace Identification (simplified)
%
% Input parameters:
%  - Y: Output data block (k x m)
%  - maxdim: Assumed maximum possible system dimension
%  - d: System dimension (optional)
% Return parameters:
%  - A,C: System matrices
%  - Rxx,Ryy,Rxy: Noise covariance matrices
%  - X: State sequence (k x d)
%
% Heikki Hyotyniemi Feb.1, 2001


A = NaN; C = NaN;
Rxx = NaN; Ryy = NaN; Rxy = NaN; X = NaN;
[k,m] = size(Y);

YY = zeros(k-2*maxdim+1,2*maxdim*m);
for i = 1:2*maxdim
   YY(:,(i-1)*m+1:i*m) = Y(i:k-2*maxdim+i,:);
end
YP = YY(:,1:maxdim*m);
YF = YY(:,maxdim*m+1:2*maxdim*m);

if nargin==3
   theta = RegrPCA(YP,d);
else
   theta = RegrPCA(YP);
   d = size(theta,2);
end

X = YP*theta;
XP = X(1:size(X,1)-1,:);
XF = X(2:size(X,1),:);

LHS = [XF,YP(1:size(YF,1)-1,(maxdim-1)*m+1:maxdim*m)];
RHS = [XP];
RR = RHS'*RHS;
AC = (pinv(RR)*RHS'*LHS)'; 

A = AC(1:d,1:d);
C = AC(d+1:d+m,1:d);

E = LHS - RHS*AC';
EE = E'*E/k;
Rxx = EE(1:d,1:d);
Ryy = EE(d+1:d+m,d+1:d+m);
Rxy = EE(1:d,d+1:d+m);

[Yhat0,Yhat1] = RegrKalm(Y,A,C,Rxx,Ryy,Rxy);

fig = figure;
clf;
set(fig,'Name','Matching the model against data');
for i = 1:m
    subplot(m,1,i);
    hold on;
    plot(Y(:,i),'*');
    plot(Yhat0(:,i),'r');
    plot(Yhat1(:,i),'g');
end
legend('Data','Filter output','One-step predictor');
title('Estimate (solid lines) against the measurements');
hold off;

