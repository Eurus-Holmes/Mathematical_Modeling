
function [F,error] = RegrRR(X,Y,q)

%   [F,error] = RegrRR(X,Y,q)
%   [F,error] = RegrRR(X,Y)
%
% Ridge Regression.
%
% Input parameters:
%  - X: Input data block (k x n)
%  - Y: Output data block (k x m)
%  - q: Stabiliaztion factor (optional)
%    If not given, estimated from data
% Return parameters:
%  - F: Mapping matrix, Yhat = X*F
%  - error: Prediction errors
%
% Heikki Hyotyniemi Aug. 21, 2003


F = NaN, error = NaN;
[kx,n] = size(X);
[ky,m] = size(Y);
if kx ~= ky, disp('Incompatible X and Y'); break; end

if nargin == 2   % Matching against parameter error
    S = zeros(n,1);
    F = zeros(n,m);
    for i = 1:10
        F = inv(X'*X)*X'*Y;  % Basic solution
        F = F * inv(diag(1+S));
        Yhat = X*F;
        error = Yhat - Y;
        S = diag(error'*error)/k;
    end
else   % Normal ridge regression
    F = inv(X'*X+q*eye(n))*X'*Y;
    Yhat = X*F;
    error = Yhat - Y;
end
