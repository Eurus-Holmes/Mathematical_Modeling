
function [X,backmap] = RegrWeight(DATA,w)

%   [X] = RegrWeight(DATA,w)
%
% Function for weighting different samples
% (for implementing weighted least squares
% or compensation of heteroscedasticity)
%
% Input parameter:
%  - DATA: Data to be manipulated (k x n)
%  - w: Sample importances (k x 1)
% Return parameters:
%  - X: Modified data matrix
%
% Heikki Hyotyniemi Dec.1, 2000


[k,n] = size(DATA);
if (n>k) disp('Data matrix should be transposed?'); end

X = DATA.*(w*ones(1,n));
