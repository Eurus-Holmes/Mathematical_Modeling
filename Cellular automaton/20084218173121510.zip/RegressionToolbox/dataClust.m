
function [X] = DataClust(n,N,kk,cm,cd)

%   [X] = DataClust(n,N,kk,cm,cd)
%   [X] = DataClust
%
% Function generates random clustered data.
%
% Input parameters:
%  - n: Data dimension (default 3)
%  - N: Number of clusters (default 2)
%  - kk: Data samples in each cluster (default 100)
%  - cm: Deviation of the cluster centers (default 1)
%  - cd: Cluster "spread", 'longest' axis vs. 'shortest' (default 1)
% Return parameters:
%  - X: Input data matrix (collection of row data vectors)
%
% Heikki Hyotyniemi Feb.12, 2001


if nargin < 1 | isnan(n)
   n = 3;
end
if nargin < 2 | isnan(N)
   N = 2;
end
if nargin < 3 | isnan(kk)
   kk = 100;
end
if nargin < 4 | isnan(cm)
   cm = 1;
end
if nargin < 5 | isnan(cd)
   cd = 1;
end

X = zeros(N*kk,n);
for i = 1:N
   XX = randn(kk,n);
   R = XX'*XX/n;
   [V,L] = eig(R);
   [L,order] = sort(diag(L));
   V = V(:,order);
   L = diag(logspace(-log10(cd^2)/2,log10(cd^2)/2,n));
   R = V*L*inv(V);
   XX = XX*sqrtm(R);
   X((i-1)*kk+1:i*kk,:) = XX + cm*ones(kk,1)*randn(1,n);
end

ind = randperm(N*kk);
X = X(ind,:);

