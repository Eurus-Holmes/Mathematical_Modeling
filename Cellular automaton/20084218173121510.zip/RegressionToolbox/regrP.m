
function [p] = RegrP(X1,X2)

%   [p] = RegrP(X1,X2)
%
% Fitting data against a Gaussian distribution.
%
% Input parameters:
%  - X1: Input data block determining distribution (k1 x n)
%  - X2: Data block to be fitted (k2 x n)
% Return parameter:
%  - p: Probabilities for data X2 to match distribution X1:
%       How probably an x1 vector is farther from the center
%
% Heikki Hyotyniemi Aug. 21, 2003


p = NaN;
[k1,n] = size(X1);
[k2,n2] = size(X2);
p = NaN*ones(k2,1);
if n ~= n2, disp('Incompatible X1 and X2'); break; end

Sigma = X1'*X1/k1;
for i = 1:k2
    x2 = X2(i,:)';
    x = x2'*inv(Sigma)*x2;
    p(i) = 1 - gammainc(x/2,n/2);
end
